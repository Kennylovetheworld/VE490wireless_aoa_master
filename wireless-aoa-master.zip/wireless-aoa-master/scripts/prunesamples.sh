#!/bin/bash


python /root/aoa/trim_data.py $1 $2
# python /root/aoa/trim_data.py /root/aoa/data/rx2_$1.dat /root/aoa/data/trimmed_rx2_$1.dat
# python /root/aoa/trim_data.py /root/aoa/data/rx3_$1.dat /root/aoa/data/trimmed_rx3_$1.dat
# python /root/aoa/trim_data.py /root/aoa/data/rx4_$1.dat /root/aoa/data/trimmed_rx4_$1.dat
echo Done with trimming the files


 
