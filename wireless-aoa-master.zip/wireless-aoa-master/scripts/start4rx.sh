#!/bin/bash


/root/aoa/4rx_to_file --freq=916000000 --rate=1000000 --gain=25 --run=$1 --runtime 4
echo ./4rx_to_file --freq=916000000 --rate=1000000 --gain=25 --run=$1

